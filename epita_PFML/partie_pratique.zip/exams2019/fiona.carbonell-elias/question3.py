import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.svm import LinearSVC

df = pd.read_csv('titanic.csv')[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()

df.sex = list(map(lambda x: {'male': 0, 'female': 1}[x], df.sex))

# Question 3

x = df[['age']]
y = df.survived

ref = list(np.linspace(4, 5 ,100))
# Ne veux pas fit le modèle. 
# Erreur à cause du x et y mais ne comprends pas pourquoi.

for k in [1, 10, 100]:
        lsvc = LinearSVC(C=k, random_state=0)
        lsvc.fit(x, y)
        b, a = list(lsvc.coef_[0]), lsvc.intercept_[0]



plt.legend()
plt.show()

