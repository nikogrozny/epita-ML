import pandas as pd
from scipy.stats import chisquare

df = pd.read_csv('titanic.csv')[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()

# Question 2

# Utilisé pour le tableau croisé d'effectif.
# Ne veux pas marcher, ne comprends pas pourquoi
#print(df.pivot(index='survived', columns='pclass'))

# Utilisé pour tester hypothèse d'indépendance
print(chisquare(df.pclass, df.survived))
