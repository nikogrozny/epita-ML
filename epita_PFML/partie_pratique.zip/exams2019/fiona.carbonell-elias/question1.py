import pandas as pd
from matplotlib import pyplot as plt
from matplotlib import patches

df = pd.read_csv('titanic.csv')[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()


# Question 1
df.sex = list(map(lambda x: {'male': 0, 'female': 1}[x], df.sex))

def color(x):
    return {0: 'red', 1: 'blue'}[x]


plt.scatter(df.age, df.fare, c= df.survived.apply(color))

colornames = [patches.Patch(color='blue', label='survived'),
                patches.Patch(color='red', label='no survived')]
plt.legend(handles=colornames)
plt.show()
