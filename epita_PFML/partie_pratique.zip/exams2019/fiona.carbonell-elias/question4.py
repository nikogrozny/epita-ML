import pandas as pd
from sklearn.tree import DecisionTreeClassifier

df = pd.read_csv('titanic.csv')[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()

df.sex = list(map(lambda x: {'male': 0, 'female': 1}[x], df.sex))

x = df[['age', 'fare', 'sex', 'pclass']]
y = df.survived

dtc = DecisionTreeClassifier()
dtc.fit(x, y)
print("score: ", dtc.score(x, y))
