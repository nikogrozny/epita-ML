import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import LinearSVC
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from pandas.plotting import scatter_matrix
from sklearn.metrics import confusion_matrix

if __name__ == "__main__":

    # 1

    FILE = "titanic.csv"

    df = pd.read_csv(FILE)

    df = df[["age", "fare", "sex", "pclass", "survived"]]

    df = df.dropna()

    df["sex"] = df["sex"].apply(lambda x: 1 if x == "female" else 0)

    fig, ax = plt.subplots()

    ax.scatter(df["age"], df["fare"], c=df["survived"])

    #plt.show()

    # 2

    #scatter_matrix(df[["sex", "pclass"]], diagonal='hist')

    # 3

    x_train, x_test, y_train, y_test = train_test_split(df[["age", "fare"]], df["survived"], test_size=0.33, random_state=42)

    pen = [1, 10, 100]

    for p in pen:

        model = LinearSVC(C=p, random_state=0)
        model.fit(x_train, y_train)
    #print(model.coef_)
    #ax.plot(model.coef_)

    #plt.show()
        b, a = list(model.coef_[0]), model.intercept_[0]
        r = np.linspace(0, 100, 5)
        ax.plot(r, [-b[0]*x/b[1]-a/b[1] for x in r], label=str(p))
        print("SVC score penalization=" + str(p))
        print(model.score(x_test, y_test))

    #plt.legend()
    #plt.show()

    # 4

    x_train, x_test, y_train, y_test = train_test_split(df[["age", "fare", "sex", "pclass"]], df["survived"], test_size=0.33, random_state=42)

    tree = DecisionTreeClassifier()

    tree.fit(x_train, y_train)

    print("Tree score:")

    print(tree.score(x_test, y_test))

    y_pred = tree.predict(x_test)

    print("confusion matrix:")
    print(confusion_matrix(y_test, y_pred))
    
    plt.legend()
    plt.show()
