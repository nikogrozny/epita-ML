import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split

csv = pd.read_csv("titanic.csv")

csv.sex = csv.sex.apply(lambda x: {'male': 0,'female': 1}[x])

csv = csv[["age", "sex", "fare", "pclass", "survived"]].dropna()

# On evite d'overfit, à ce qui parait, c'est une mauvaise idée.
train_x, test_x, train_y, test_y = train_test_split(csv[["age", "sex", "fare", "pclass"]], csv["survived"], test_size=0.2, random_state=0)

# Si on overfit, on monte à un score de 97%

for model in [
    #DecisionTreeClassifier(random_state=0),
    DecisionTreeClassifier(criterion='entropy', random_state=0)
    #DecisionTreeClassifier(max_features='auto', random_state=0)
        ]:
    model.fit(train_x, train_y)

    print(model.score(test_x, test_y))

