import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

csv = pd.read_csv("titanic.csv")

csv.sex = csv.sex.apply(lambda x: {'male': 0,'female': 1}[x])

csv = csv[["age", "sex", "fare", "pclass", "survived"]]

plt.scatter(csv["age"], csv["fare"],c=np.vectorize(lambda x: ["red", "green"][x])(csv["survived"]))
plt.show()
