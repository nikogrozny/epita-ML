import pandas as pd
import matplotlib.pyplot as plt

csv = pd.read_csv("titanic.csv")

csv.sex = csv.sex.apply(lambda x: {'male': 0,'female': 1}[x])

csv = csv[["age", "sex", "fare", "pclass", "survived"]]

print("Tableau croisé", pd.crosstab(csv["sex"], csv["pclass"]))
print("Independance", csv[["sex","pclass"]].corr())

# Corrélationde -0.12, il sont partiquement indépedant
