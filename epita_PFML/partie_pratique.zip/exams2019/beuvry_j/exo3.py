import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import LinearSVC

csv = pd.read_csv("titanic.csv")

csv.sex = csv.sex.apply(lambda x: {'male': 0,'female': 1}[x])

csv = csv[["age", "sex", "fare", "pclass", "survived"]]


ref = np.linspace(0, csv["age"].max(), 100)

df = csv[["age", "fare", "survived"]].dropna()

for index, penalisation in enumerate([1, 10, 100]): 
    plt.subplot(1, 3, index + 1)

    plt.scatter(csv["age"], csv["fare"], c=np.vectorize(lambda x: ["red", "green"][x])(csv["survived"]))
    model = LinearSVC(C=penalisation, random_state=1)
    model.fit(df[["age", "fare"]], df["survived"])

    b, a = list(model.coef_[0]), model.intercept_[0]

    plt.plot(ref, [-b[0] * x / b[1] -a / b[1] for x in list(ref)], label=str(penalisation))

    plt.xlabel("age")
    plt.xlabel("fare")

plt.show()
