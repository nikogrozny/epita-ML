import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from matplotlib import patches
from sklearn import tree
from sklearn import svm
from scipy.stats import chi2_contingency

# Question 1

path = "titanic.csv"
data = pd.read_csv(path)[["age", "fare", "sex", "pclass", "survived"]].dropna()
lut_sex = dict(zip(data.sex.unique(), range(2)))
data.sex = [lut_sex[i] for i in data.sex]
colors = ["yellow" if s else "brown" for s in data.survived]

plt.figure()
plt.scatter(data.age, data.fare, c = colors)
plt.legend(handles = [patches.Patch(color = "yellow", label = "survived")])
plt.show()

# Question 2

tab = pd.crosstab(data.sex, data.pclass)
print(tab)
print(chi2_contingency(tab)[1])

# Question 3

clf_1 = svm.LinearSVC(C=1)
clf_1.fit(data[["age", "fare"]], data.survived)

clf_10 = svm.LinearSVC(C=10)
clf_10.fit(data[["age", "fare"]], data.survived)

clf_100 = svm.LinearSVC(C=100)
clf_100.fit(data[["age", "fare"]], data.survived)

plt.figure()
ax = plt.subplot(131)
plt.title("penalisation: 1")
plt.scatter(data.age, data.fare, c = colors)
plt.legend(handles=[patches.Patch(color = "yellow", label="survived")])
a, b = clf_1.coef_[0]
ax.plot([0, 80],[b, 80 * a + b])

ax = plt.subplot(132)
plt.title("penalisation: 10")
plt.scatter(data.age, data.fare, c = colors)
plt.legend(handles=[patches.Patch(color = "yellow", label="survived")])
a, b = clf_10.coef_[0]
ax.plot([0, 80],[b, 80 * a + b])

ax = plt.subplot(133)
plt.title("penalisation: 100")
plt.scatter(data.age, data.fare, c = colors)
plt.legend(handles=[patches.Patch(color = "yellow", label="survived")])
a, b = clf_100.coef_[0]
ax.plot([0, 80],[b, 80 * a + b])
plt.show()
print(a, b)

# Question 4

t = tree.DecisionTreeClassifier()
dataset = data[["age", "fare", "sex", "pclass"]]
t.fit(dataset[:750], data.survived[:750]) # split dataset into train and test datasets
print(t.score(dataset[750:], data.survived[750:]))
