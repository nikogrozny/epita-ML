import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as scs
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

df = pd.read_csv("titanic.csv", sep=',')
df = df[['age','fare', 'sex', 'pclass', 'survived']]
l = list(df['sex'])
df['sex'] = df['sex'].apply(lambda x : l.index(x))

fig = plt.figure()
fig.add_axes()
ax1 = fig.add_subplot(111)
def colors(d):
    return {1 :'green', 0 : 'yellow'}[d]
ax1.scatter(df.age, df.fare, c= df.survived.apply(colors))
plt.show()

ct = pd.crosstab(df['sex'], df['pclass'])
print("pvalue : %f" % scs.chi2_contingency(ct)[1])
train_data = df[['age', 'fare', 'survived']].dropna(axis=0)

train_data_x = train_data[['age','fare']][:-20]
test_data_x = train_data[['age','fare']][-20:]
train_data_y = train_data.survived[:-20]
test_data_y = train_data.survived[-20:]

s1 = SVC(kernel = 'linear', C = 1)
s1.fit(train_data_x, train_data_y)
ypred1 = s1.predict(test_data_x)
print("Linear SVM with penalization 1 : Done")

s10 = SVC(kernel = 'linear', C = 10)
s10.fit(train_data_x, train_data_y)
ypred10 = s10.predict(test_data_x)
print("Linear SVM with penalization 10 : Done")

s100 = SVC(kernel = 'linear', C = 100)
s100.fit(train_data_x, train_data_y)
ypred100 = s100.predict(test_data_x)
print("Linear SVM with penalization 100 : Done")

plt.scatter(test_data_x.age, test_data_x.fare, c = test_data_y.apply(colors))
plt.plot(test_data_x.age, ypred1, color = 'red', linewidth = 1)
plt.show()


train_data_tree = df.dropna(axis=0)[:-20]
test_data_tree = df.dropna(axis=0)[-20:]
tree = DecisionTreeClassifier()
tree.fit(train_data_tree[['age','fare','sex', 'pclass']], train_data_tree.survived)
print("Accuracy : %f%%" % (tree.score(test_data_tree[['age','fare','sex','pclass']], test_data_tree.survived) * 100))
