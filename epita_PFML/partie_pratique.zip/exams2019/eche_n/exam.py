import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from sklearn.svm import SVC

# Question 1

# Import data
df = pd.read_csv("titanic.csv")
keeped_columns = ["age", "fare", "sex", "pclass", "survived"]

df = df[keeped_columns].dropna()

df.sex = df.sex.apply(lambda x: 1 if x=='Male' else 0)

def survived_color(x):
    return {1:'green', 0:'red'}[x]


plt.subplot(1,1,1)
plt.scatter(df.age, df.fare, c=df.survived.apply(survived_color))

plt.xlabel = 'Age'
plt.ylabel = 'Fare'

plt.show()

# Question 2

# A la recherche de la fonction cross_table... 
# print(df[['sex', 'pclass']].cross_table)

# L'indépendance peut-etre vérifier (ou non) grace à scipy.stats.chi2 quelque chose si je retrouve cette fonction 
# et que je lui donne en parametre la cross table en np.array...


# Question 3

svm = SVC(kernel='linear')
x = df[['age', 'fare']]
y = df.survived
print(len(x))
x_train, x_val = x[:800], x[800:]
y_train, y_val = y[:800], y[800:]
print(len(x_train), len(x_val))

svm.fit(x_train, y_train)
print('SVM score = ', svm.score(x_val, y_val))
y_pred = pd.Series(svm.predict(x_val))

plt.subplot(1,1,1)
plt.scatter(x_val.age, x_val.fare, c=y_pred.apply(survived_color), alpha=0.4)
plt.scatter(x_val.age, x_val.fare, c=y_val.apply(survived_color))
drt = np.arange(0,80, 0.1).reshape(-1, 1)
plt.plot(drt, drt * svm.coef_)
print(svm.coef_)
plt.show()

# les droite ne sembles pas correcte...

# Question 4

from sklearn.tree import DecisionTreeClassifier

x = df[['age', 'fare', 'sex', 'pclass']]
y = df.survived
print(len(x))
x_train, x_val = x[:800], x[800:]
y_train, y_val = y[:800], y[800:]
print(len(x_train), len(x_val))

dtc = DecisionTreeClassifier()

dtc.fit(x_train, y_train)

print('DECISION TREE Score = ', dtc.score(x_val, y_val))

# les resultat serait plus probant en séparant mieux train et val grace à la fonction split_train_test de sklearn que je vais tenter d'incorporé avant le rendu final
