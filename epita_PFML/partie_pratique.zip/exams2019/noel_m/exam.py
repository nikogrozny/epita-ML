import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix

#Question 1
df = pd.read_csv("./titanic.csv")

df = df[["age", "fare", "sex", "pclass", "survived"]].dropna()
sex_to_int = {'male':0, 'female':1}
df["sex"] = df.sex.replace(sex_to_int)

plt.scatter(df.age, df.fare, c=df.survived)
plt.show()


#Question 2
print(pd.crosstab(df["sex"], df["pclass"]))
# pour tester l'hypotese d'independance on doit calculer la p_value mais je ne sais
# plus comment


#Question 3

x = np.array([i for i in range(90)])
for i, loss in enumerate([1, 10, 100]):

    svc = SVC(kernel='linear', C=loss)
    svc.fit(df[["age", "fare"]], df["survived"])
    plt.subplot(1,3,i+1)
    plt.title("pred with loss = {}".format(loss))
    #display survived prediction as color
    plt.scatter(df.age, df.fare, c=svc.predict(df[["age", "fare"]]))
    plt.plot(x, [i*svc.coef_[0][0] + svc.coef_[0][1] for i in x])

plt.show()

#Question 4
X, y = df[["age", "fare", "sex", "pclass"]], df["survived"]

#separate into test and train set
X_train, X_test, y_train, y_test = train_test_split(X, y)

#init with default param and fit on train set
dtc = DecisionTreeClassifier()
dtc.fit(X_train, y_train)
#make prediction on test set
y_pred = dtc.predict(X_test)
#print confusion matrix 
print(confusion_matrix(y_test, y_pred))
#print score
print("Score :", dtc.score(X_test, y_test))

