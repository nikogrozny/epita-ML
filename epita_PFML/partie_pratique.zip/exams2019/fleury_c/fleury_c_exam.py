import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split

# Question 1

data = pd.read_csv("./titanic.csv")

data_sf = data[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()

data_sf.sex = data_sf.sex.apply(lambda x: {'male':0, 'female':  1}[x])
plt.scatter(data_sf['age'], data_sf['fare'], c=data_sf.survived)
plt.show()

# Question 2

print(pd.crosstab(data_sf['pclass'], data_sf['survived']))
# je sais que c'est pas ce qui est demandé, mais je me souvenais plus de la commande...

# Test corrélation
print(data_sf[['pclass', 'survived']].corr())

# Question 3

pens = [1, 10, 100]


for p in pens:
    # 64, parceque.
    model = LinearSVC(C=p, random_state=64)
    model.fit(data_sf[['age', 'fare']], data_sf['survived'])
    r = model.predict(data_sf[['age', 'fare']])
    # Oui on fait pas de split, mais le but n'étant pas de l'evaluer ici (pour le tree on le fera)
    X1 = data_sf['age']
    X2 = data_sf['fare']
    plt.scatter(X1, X2, c=r)
    m = np.arange(0,80,0.1)
    w = model.coef_[0]
    a = -w[0] / w[1]
    xx = np.linspace(-5, 85)
    yy = a * xx - (model.intercept_[0] / w[1])
    plt.plot(xx, yy)

    plt.show()


# Question 4

t = DecisionTreeClassifier()

X_train, X_test, Y_train, Y_test = train_test_split(data_sf[['fare', 'age', 'sex', 'pclass']], data_sf['survived'], test_size=0.2)

t.fit(X_train, Y_train)
print("Tree score : {}".format(t.score(X_test, Y_test)))
