import pandas as pd
import matplotlib.pyplot as plt

##question 1

df = pd.read_csv("titanic.csv", ",")


df2 = df[["age","fare","sex","pclass","survived"]].dropna()

df2.sex = df2.sex.apply(lambda x:{'male':0, 'female':1}[x])
def color(d):
    return {1: "green", 0: "yellow"}[d]


plt.scatter(df2.age, df2.fare, c=df2.survived.apply(color))
plt.show()


##question 2

from pandas.plotting import scatter_matrix
scatter_matrix(df2[['sex','pclass']], alpha=0.6, c=df2.survived.apply(color), diagonal='hist')
plt.show()

##question 3

from sklearn.svm import SVC
from random import shuffle

X, Y = df2[['age','fare']], df2.survived
i_train = list(range(len(X)))
shuffle(i_train)
X_train = X.loc[X.index.isin(i_train[:400])]
Y_train = Y.loc[Y.index.isin(i_train[:400])]
X_test = X.loc[X.index.isin(i_train[400:])]

s = SVC(kernel='linear')
s.fit(X_train, Y_train)
Y_pred = pd.Series(s.predict(X_test))

plt.scatter(X_test.age, X_test.fare, c=Y_pred.apply(color))
plt.show()

##question 4

from sklearn import tree

Xb, Yb = df2[['age','fare','sex','pclass']], df2.survived
i_train = list(range(len(X)))
shuffle(i_train)
Xb_train = Xb.loc[Xb.index.isin(i_train[:400])]
Yb_train = Yb.loc[Yb.index.isin(i_train[:400])]
Xb_test = Xb.loc[Xb.index.isin(i_train[400:])]
Yb_test = Yb.loc[Yb.index.isin(i_train[400:])]

clf = tree.DecisionTreeClassifier()
clf.fit(Xb_train, Yb_train)

print(clf.score(Xb_test, Yb_test))





