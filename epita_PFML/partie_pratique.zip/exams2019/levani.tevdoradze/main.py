import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import patches
from sklearn.svm import LinearSVC
from pandas.plotting import scatter_matrix
from sklearn.tree import DecisionTreeClassifier

#ex1
df = pd.read_csv('titanic.csv')
df = df[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()
def ston(x):
    if x == 'male':
        return 0
    else:
        return 1
df.sex = df.sex.apply(lambda x: ston(x))
fig = plt.figure()
ax = fig.add_subplot(111)
colors = {0: 'red', 1:'green'}
ax.scatter(df['age'], df['fare'], c=df.survived.apply(lambda x: colors[x]))
colornames = [patches.Patch(color='green', label='survived'), patches.Patch(color='red', label='no')]
plt.legend(handles=colornames)
plt.show()

#ex3
clf = LinearSVC()
clf.fit(df[['age', 'fare']], df[['survived']])
scatter_matrix(df[['age', 'fare', 'survived']], alpha=0.6)
plt.show()

#ex4
clf2 = DecisionTreeClassifier()
X = df[['age', 'fare', 'sex', 'pclass']]
Y = df[['survived']]
clf2.fit(X,Y)
