import pandas as pd
import matplotlib.pyplot as plt
from sklearn import svm
from sklearn import tree
from scipy.stats import chi2_contingency
from sklearn.model_selection import train_test_split
import numpy as np

# Q1

PATH = 'titanic.csv'

df = pd.read_csv(PATH)

df = df[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()
df['sex'] = [0 if s == 'male' else 1 for s in df['sex']]
print(df.head())
plt.scatter(df.age, df.fare, c=df.survived)

# Q2
print(pd.crosstab(df.sex, df.pclass))
cont = df[['sex', 'pclass']]
# p-value faible => pas de correlation
print('p value:', chi2_contingency(cont)[1])


# Q3

for i in range(3):
    print('training with penalisation:', 10**i)
    cls = svm.SVC(C=10**i, kernel='linear', verbose=True)
    cls.fit(df[['age', 'fare']], df.survived)
    ages = df.age.unique()
    print(cls.coef_)
    # unique
    test = df[['age', 'fare']].sort_values('age')
    
    plt.plot(test.age, (cls.intercept_ - cls.coef_[0][0] * test.age) / cls.coef_[0][1])

plt.show()


# Q4

dt = tree.DecisionTreeClassifier()
X_train, X_test, y_train, y_test = train_test_split(df[['age', 'fare', 'sex', 'pclass']], df.survived, random_state=0)


dt.fit(X_train, y_train)

print('score:', dt.score(X_test, y_test))

