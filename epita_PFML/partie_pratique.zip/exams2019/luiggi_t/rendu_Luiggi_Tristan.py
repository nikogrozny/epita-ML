#! /usr/bin/python3

import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from scipy.stats import chi2_contingency

PATH_TO_RESSOURCES = "titanic.csv"


# Question 1

# Read Data

data = pd.read_csv(PATH_TO_RESSOURCES)


# keeping age, fare and sex fields

data = data[['age', 'fare', 'sex', 'pclass', 'survived']]
data = data.dropna()

# Convert sex field into 0 and 1

data.sex = pd.Categorical(data.sex)
data.sex = data.sex.cat.codes


plt.scatter(data.age, data.fare, c = data.survived)
plt.ylabel("fare")
plt.xlabel("age")


plt.show()


# Question 2

pd.plotting.scatter_matrix(data[['age', 'fare', 'survived']])
plt.show()

print("Chi test : ", chi2_contingency(data[['age', 'fare']]))

# Question 3

x2 = np.linspace(0,550,1000)
x1 = np.linspace(0, 80, 1000)

line = np.vstack([x1, x2]).T

train = []
penalty = [1, 10, 100]

for p in penalty : 
	svm = SVC(C = p)
	svm.fit(data[['age', 'fare']], data.survived)
	train.append(svm.support_vectors_)

plt.scatter(data.age, data.fare, c = data.survived)
plt.ylabel("fare")
plt.xlabel("age")

i = 0
for l in train : 
		plt.plot(l[0:85], label="Penalty = {0}".format(penalty[i]))
		i += 1
plt.show()


# Question 4

train_x, test_x, train_y, test_y = train_test_split(data[['age', 'fare', 'sex', 'pclass']], data.survived)

dt = DecisionTreeClassifier()

dt.fit(train_x, train_y)

print("Score : ", dt.score(test_x, test_y))

