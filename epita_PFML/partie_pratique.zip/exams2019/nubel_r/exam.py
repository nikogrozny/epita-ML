import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.svm import SVC, LinearSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from pandas.plotting import scatter_matrix

data = pd.read_csv("titanic.csv")
data = data[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()

data.sex = pd.Categorical(data.sex)
data.sex = data.sex.cat.codes

train, test , trainy, testy= train_test_split(data[['age', 'fare', 'sex', 'pclass']], data.survived, test_size=0.2)


plt.scatter(data.age, data.fare, c=data.survived)
plt.show()
scatter_matrix(data[['sex', 'pclass']], c=data.survived)
plt.show()

svm = SVC()
svm2 = SVC(C=10)
svm3 = SVC(C=100)

svm.fit(train[['age', 'fare']], trainy)
svm2.fit(train[['age', 'fare']], trainy)
svm3.fit(train[['age', 'fare']], trainy)

pred = svm.predict(test[['age', 'fare']])
pred2 = svm2.predict(test[['age', 'fare']])
pred3 = svm3.predict(test[['age', 'fare']])


plt.subplot(321)
plt.scatter(test.age, test.fare, c=pred, alpha=0.2)
plt.scatter(train.age, train.fare, c=trainy)
plt.title('SVM pénalité 1')
plt.subplot(322)
plt.scatter(data.age, data.fare, c=data.survived)
plt.title('Real data')


plt.subplot(323)
plt.scatter(test.age, test.fare, c=pred2, alpha=0.2)
plt.scatter(train.age, train.fare, c=trainy)
plt.title('SVM pénalité 10')
plt.subplot(324)
plt.scatter(data.age, data.fare, c=data.survived)
plt.title('Real data')


plt.subplot(325)
plt.scatter(test.age, test.fare, c=pred3, alpha=0.2)
plt.scatter(train.age, train.fare, c=trainy)
plt.title('SVM pénalité 100')
plt.subplot(326)
plt.scatter(data.age, data.fare, c=data.survived)
plt.title('Real data')




plt.show()


tree = DecisionTreeClassifier(random_state=0)
tree.fit(train, trainy)

print("DecisionTree score:", tree.score(test, testy))

