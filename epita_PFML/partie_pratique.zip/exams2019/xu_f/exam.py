import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder

# chargement des données

file_path = "titanic.csv"
data = pd.read_csv(file_path)

# Question 1

data = data[["age", "fare", "sex", "pclass", "survived"]].dropna()
data.sex = LabelEncoder().fit_transform(data.sex)

colors = np.array(["red", "green"])

plt.scatter(data.pclass, data.survived, c=colors[data.survived])
plt.show()

# Question 2

cross = np.zeros((2, 3))
for row in data.iterrows():
    sex = row[1].sex.astype(np.int)
    pclass = row[1].pclass.astype(np.int) -1
    cross[sex][pclass] += 1

print(cross)
print("Correlation score: " + str(data.corr().pclass.sex))

# Les variables sont indépendantes

# Question 3

from sklearn.svm import LinearSVC

survived = [LinearSVC(C=k, max_iter=10000, random_state=10) for k in [1, 10, 100]]

X = data[["age", "fare"]].values
y = data.survived.values

for i in range(len(survived)):
    survived[i] = survived[i].fit(X, y)


plt.scatter(data.age, data.fare, c=colors[data.survived])

line_x = np.linspace(0, 80, 100)
line_colors = ["blue", "orange", "black"]

for i in range(len(survived)):
    c = survived[i].coef_[0]
    it = survived[i].intercept_
    y = [  (-x * c[0] / c[1]) - (it[0] / c[1]) for x in line_x]
    plt.plot(line_x, y, c=line_colors[i])

plt.show()

# Question 4

from sklearn.tree import DecisionTreeClassifier

X = data[["age", "fare", "sex", "pclass"]].values
y = data.survived.values

tree = DecisionTreeClassifier().fit(X, y)

from sklearn.metrics import classification_report

predicted = tree.predict(X)
print(classification_report(y, predicted))
