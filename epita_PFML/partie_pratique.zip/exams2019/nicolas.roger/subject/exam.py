import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score
from scipy.stats import chi2_contingency


data = pd.read_csv("titanic.csv")[["age","fare","sex","pclass", "survived"]].dropna()
sex_to_id = dict(zip(data["sex"], np.arange(len(np.unique(data["sex"])))))
sex_id = [sex_to_id[val] for val in  data["sex"].values]
data["sex"] = sex_id
plt.show()
#print(data[:10])
#print(data.columns)

pclass = data["pclass"].values + np.random.randn(len(data["pclass"].values))*0.05
survived = data["survived"].values + np.random.randn(len(data["survived"].values))*0.05
colors = ['b' if val else 'r' for val in data['survived']]

plt.plot(pclass, survived, "o", c='b')
plt.show() 

# p > 0.05 on ne rejette pas H0
_,p,_,_ = chi2_contingency([data['survived'].values,data['pclass'].values])
print(p)

for c in [1,10,100]:
    svm = SVC(kernel="linear", C=c)
    svm.fit(data[["age", "fare"]], data["survived"])

X = data[["age", 'fare', 'pclass', 'sex']]
Y = data["survived"]
tree = DecisionTreeClassifier()
tree.fit(X,Y)
scores = cross_val_score(tree,X,Y)
#print(scores.means())
