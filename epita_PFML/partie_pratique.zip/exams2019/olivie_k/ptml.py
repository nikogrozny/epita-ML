import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency
from sklearn.svm import LinearSVC
from sklearn import tree


#Question 1
data = pd.read_csv('titanic.csv')

data = data[['age', 'fare', 'sex', 'pclass', 'survived']]

data = data.dropna()

data['sex'] = data['sex'].map({'male': 0, 'female': 1})

print(data.head())

fig = plt.figure()
fig.title = 'question 1'
ax = fig.add_subplot(111)

ax.scatter(data['age'], data['fare'], c=data['survived'])

fig.show()

#Question 2
print('Question 2')
c1 = pd.crosstab(data['pclass'], data['survived'])
_, p1, _, _ = chi2_contingency(c1)
print(c1)
print(p1)

#Question 3
print('Question 3')

X = data[["age", 'fare']]
Y = data['survived']
clf1 = LinearSVC(C=1)
clf1.fit(X, Y)
ypred1 = clf1.predict(X)

clf2 = LinearSVC(C=10)
clf2.fit(X, Y)

clf3 = LinearSVC(C=100)
clf3.fit(X, Y)

w = clf1.coef_[0]
a = -w[0] / w[1]
xx = np.linspace(0,80)
yy = a * xx - clf1.intercept_[0] / w[1]

w1 = clf2.coef_[0]
a1 = -w1[0] / w1[1]
yy1 = a1 * xx - clf2.intercept_[0] / w1[1]

w2 = clf3.coef_[0]
a2 = -w2[0] / w2[1]
yy2 = a2 * xx - clf3.intercept_[0] / w2[1]

fig2 = plt.figure()
ax.xlim = (0,data['age'].max())
ax.ylim = (0, data['fare'].max())
ax = fig2.add_subplot(111)

ax.scatter(data['age'], data['fare'], c=ypred1)
ax.plot(xx, yy)
ax.plot(xx, yy1)
ax.plot(xx, yy2)

# ATTENTION
# ATTENTION, il faut reload le script quelque fois avant que cela marche (max 10 fois).
# Je pense que c'est la faute des echelles mais j'arrive pas a fix meme en touchant a XLIM

# Meme avec max_iter=100000, les warning sont encore la, donc je les laisse.

fig2.show()

plt.show()

# Question 4
print('Question 4')
X1 = data[['age', 'fare', 'sex', 'pclass']]
Y1 = data['survived']
tclf = tree.DecisionTreeClassifier()
tclf.fit(X1, Y1)
print(tclf.score(X1, Y1))



