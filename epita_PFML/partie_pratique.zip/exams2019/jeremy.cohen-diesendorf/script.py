import sklearn
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_selection import chi2
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd

def convertToInt(tab):
    res = []
    for i in tab:
        if i == "male":
            res.append(0)
        else:
            res.append(1)
    return res

def getColor(tab):
    res = []
    for i in tab:
        if i == 1:
            res.append('g')
        else:
            res.append('r')
    return res

data = pd.read_csv("titanic.csv")[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()
data.sex = convertToInt(data.sex)

#Question 1
x = np.arange(len(data.age))
plt.scatter(data.age, data.fare, c=getColor(data.survived))

#Question 2
chi = chi2(data[['sex', 'pclass']], data.survived)
print("Question 2, tableau croise d'effectifs: " + str(chi))

#Question 3
svm1 = LinearSVC(C=1).fit(data[['age', 'fare']], data.survived)
svm10 = LinearSVC(C=10).fit(data[['age', 'fare']], data.survived)
svm100 = LinearSVC(C=100).fit(data[['age', 'fare']], data.survived)
print('Question 3, Coef de la droite avec penalisation = 1: ' + str(svm1.coef_))
print('Question 3, Coef de la droite avec penalisation = 10: ' + str(svm1.coef_))
print('Question 3, Coef de la droite avec penalisation = 100: ' + str(svm1.coef_))

#Question 4
clf = DecisionTreeClassifier().fit(data[['age', 'fare', 'sex', 'pclass']], data.survived)
print('Question 4, Score: ' + str(clf.score(data[['age', 'fare', 'sex', 'pclass']], data.survived)))

plt.show()
