import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# question 1

def convert(s):
    return { "male" : 0, "female" : 1}[s]

def color(s):
    return { 0: "green", 1: "red"}[s]

data = pd.read_csv("titanic.csv")
df = data[["age", "fare", "sex", "pclass", "survived" ]]

df["sex"] = df.sex.apply(convert)

plt.scatter(df.age, df.fare, c=df.survived.apply(color))
plt.show()

# question 2

from scipy.stats import chi2_contingency

ct = pd.crosstab(df["sex"], df["pclass"])

print("Independance Test: ")
print(ct)
print(chi2_contingency(ct))

# question 3

from sklearn.svm import LinearSVC

df = df.dropna()

ref = list(np.linspace(0,80,100))
for p in [1, 10, 100]:
    svm = LinearSVC(C=p)
    svm.fit(df[["age", "fare"]], df[["survived"]])
    b, a = list(svm.coef_[0]) , svm.intercept_[0]
    plt.scatter(df.age, df.fare, c=df.survived.apply(color))
    plt.plot(ref, [-b[0] * x / b[1] - a / b[1] for x in ref])
    print("SVM coef: ")
    print(svm.coef_)

plt.show()

# question 4

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score

dt = DecisionTreeClassifier()
dt.fit(df[["age", "fare", "sex", "pclass"]], df[["survived"]])
print("tree score")
print(cross_val_score(dt, df[["age", "fare", "sex", "pclass"]], df[["survived"]]))

