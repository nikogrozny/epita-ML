import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.svm import SVC

# Question 1
datas = pd.read_csv('titanic.csv')
q1 = datas[['age', 'fare', 'sex', 'pclass', 'survived']]
q1 = q1.dropna()
q1['sex'] = [0 if x == 'male' else 1 for x in q1['sex']]

q1_s0 = q1.loc[q1['survived'] == 0]
q1_s1 = q1.loc[q1['survived'] == 1]

plt.scatter(q1_s0['age'], q1_s0['fare'], color='red')
plt.scatter(q1_s1['age'], q1_s1['fare'], color='green')
plt.show()

# Question 2
tab = [[0,0,0],[0,0,0]]
for i in range(len(tab)):
    for j in range(len(tab[0])):
        tab[i][j] = len(q1.loc[(q1['sex'] == i) & (q1['pclass'] == j+1)])

print('Tableau croise d\'effectifs')
print(tab)

print('Tableau de correlation')
print(np.corrcoef(q1['sex'], q1['pclass']))

# Question 3
svcs = [SVC(kernel='linear', C=c) for c in [1, 10, 100]]
[svc.fit(list(zip(q1['age'], q1['fare'])), q1['survived']) for svc in svcs]
[plt.plot([0, 80], [svc.coef_[0, 1], 80*svc.coef_[0, 0] + svc.coef_[0, 1]]) for svc in svcs]
plt.show()

# Question 4
from sklearn.tree import DecisionTreeClassifier
tree = DecisionTreeClassifier()
