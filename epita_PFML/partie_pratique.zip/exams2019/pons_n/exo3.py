import pandas as pd
import matplotlib.pyplot as plt
from sklearn.svm import SVC

df = pd.read_csv("titanic.csv")

df = df[["age", "fare", "sex", "pclass", "survived"]]

df = df.dropna(axis=0)

X = df[['age', 'fare']]
Y = df.survived
X_train, X_test, Y_train, Y_test = X[:1000], X[1000:], Y[:1000], Y[1000:]
s = SVC(kernel='linear')
s.fit(X_train, Y_train)
print(s.score(X_train, Y_train), s.score(X_test, Y_test))
print(s.predict(X_test)[:30])

plt.plot(s.predict(X_test)[:30])
plt.show()
