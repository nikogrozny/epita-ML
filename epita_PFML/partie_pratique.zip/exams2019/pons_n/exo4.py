import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeRegressor

df = pd.read_csv("titanic.csv")

df = df[["age", "fare", "sex", "pclass", "survived"]]

df.sex = df.sex.apply(lambda x: {'male':0, 'female':1}[x])

df = df.dropna(axis=0)

X = df[['age', 'fare', 'sex', 'pclass']]
Y = df.survived

X_train, X_test, Y_train, Y_test = X[:1000], X[1000:], Y[:1000], Y[1000:]
regr_1 = DecisionTreeRegressor()
regr_1.fit(X_train, Y_train)

print(regr_1.score(X_test, Y_test))
