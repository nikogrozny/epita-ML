import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("titanic.csv")

df = df[["age", "fare", "sex", "pclass", "survived"]]

gender = {"male": 0, "female": 1}

df.sex.apply(lambda x: gender.get(x))

def colors(d):
	return {0:'yellow', 1:'green'}[d]

plt.scatter(df.age, df.fare, c=df.survived.apply(colors)) 
plt.show()
