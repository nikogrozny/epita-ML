#question 3

import pandas as pd    # w couldn't test because there was no dataset 
import  matplotlib.pyplot as plt

df = pd.read_csv('titanic.csv',sep=",")
print(df.head())
df = df[['survived','pclass','age','fare','sex']]
transform = {'male' :0,'female':1}
surv = {1: 'blue', 0 : 'red'}
df['sex'] = df['sex'].apply(lambda x: transform.get(x))
plt.figure()




import numpy as np
from sklearn import svm
from sklearn.model_selection import train_test_split
df = df.dropna()
X,Y = df[['age','fare']], df['survived']

X_train, X_test, Y_train, y_test = train_test_split(X, Y, random_state=33)
ref = list(np.linspace(4,7,100))


plt.scatter(X_train['age'],X_train['fare'],c=Y_train)
for p in range(2,5):
    vm = svm.LinearSVC(C= 10 ** (p-2))
    vm.fit(X_train,Y_train)
    b,a = list(vm.coef_[0]),vm.intercept_[0]
    plt.plot(ref,[-b[0]*a/b[1] - a/b[1] for i in ref ],label = str(10 ** (p - 2 )))
    plt.legend()
    plt.show()
