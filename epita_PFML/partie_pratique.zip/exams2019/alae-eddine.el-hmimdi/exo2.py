#question 2
from scipy.stats import chi2
import pandas as pd    # w couldn't test because there was no dataset 
import  matplotlib.pyplot as plt
from sklearn.metrics import crosstab # j'ai pas reussit a trouver le nom de la fonction 
df = pd.read_csv('titanic.csv',sep=",")
print(df.head())
df = df[['survived','pclass','age','fare','sex']]
transform = {'male' :0,'female':1}
surv = {1: 'blue', 0 : 'red'}
df['sex'] = df['sex'].apply(lambda x: transform.get(x))




chi2(df['pclass'],df['survived'])


crosstab(df['pclass'],df['survived'])  # j'ai testé different nom , mais j'ai pas reussi a chopper le nom de la libraie qui contient la conftion crosstab a skitlearn


