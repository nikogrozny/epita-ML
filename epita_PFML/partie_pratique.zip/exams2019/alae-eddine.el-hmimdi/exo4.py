#question 4

import pandas as pd    # w couldn't test because there was no dataset 
import  matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier


df = pd.read_csv('titanic.csv',sep=",")
print(df.head())
df = df[['survived','pclass','age','fare','sex']]
transform = {'male' :0,'female':1}
surv = {1: 'blue', 0 : 'red'}
df['sex'] = df['sex'].apply(lambda x: transform.get(x))
plt.figure()




import numpy as np
from sklearn import svm
from sklearn.model_selection import train_test_split
df = df.dropna()
X,Y = df[['age','fare']], df['survived']

X_train, X_test, Y_train, y_test = train_test_split(X, Y, random_state=33)


model =RandomForestClassifier(max_depth=2,max_features='auto',max_leaf_nodes=None)
model.fit(X_train,Y_train)
#model.evaluat(X_test,Y_test)
Y_pred_test = model.predict(X_test).reshape(262,1)
print(model.feature_importances_)
model.score(Y_pred_test,y_test.reshape(262,1))
