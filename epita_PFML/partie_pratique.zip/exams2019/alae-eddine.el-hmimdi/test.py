import pandas as pd    # w couldn't test because there was no dataset 
import  matplotlib.pyplot as plt
df = pd.read_csv('titanic.csv',sep=",")
print(df.head())
df = df[['survived','pclass','age','fare','sex']]
transform = {'male' :0,'female':1}
surv = {1: 'blue', 0 : 'red'}
df['sex'] = df['sex'].apply(lambda x: transform.get(x))
plt.figure()

plt.scatter(df['age'],df['fare'],c=df.survived)

plt.show()

