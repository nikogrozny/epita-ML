import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sklearn
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier, plot_tree
from scipy import stats

csv = pd.read_csv("titanic.csv", sep=",")

csv = csv[["age", "fare", "sex", "pclass", "survived"]]

csv["sex"] = csv.astype('category')["sex"].cat.codes

plt.subplot(211)
plt.scatter(csv["age"], csv["fare"], c=csv["survived"])
# si j'ai bien compris, seul le premier subplot repond a la question
# je dessine ce deuxieme pour prouver la notion de subplot
plt.xlabel("age")
plt.ylabel("fare")
plt.subplot(212)
plt.scatter(csv["sex"], csv["pclass"], c=csv["survived"])
plt.xlabel("sex")
plt.ylabel("pclass")
plt.show()

cross = pd.crosstab(csv["sex"], csv["pclass"])
print("Le tableau croise d'effectifs est :")
print(cross)
_, p_value, _, _ = stats.chi2_contingency(cross)
print("La p-value est :")
print(p_value)
# L'ecart est faible, l'hypothese est validee

# j'ai eu l'erreur "input contained NaN, infinity or a value too large"
# j'ai ete oblige de drop les NaN bien que non demande, je ne voyais pas comment faire autrement
csv_no_na = csv.dropna()
plt.scatter(csv_no_na["age"], csv_no_na["fare"], c=csv_no_na["survived"])
ref = list(np.linspace(0, 80, 100))

# les droites de separation changent de facon TRES significative entre chaque lancement du programme
# j'ai donc fixe le random et augmente le nombre d'iterations, mais peut-etre pas suffisamment
for p in [1, 10, 100]:
    classifier = LinearSVC(C=p, max_iter=5000, random_state=7)
    classifier = classifier.fit(csv_no_na[["age", "fare"]], csv_no_na["survived"])
    b, a = list(classifier.coef_[0]), classifier.intercept_[0]
    plt.plot(ref, [-b[0] * x/b[1] - a/b[1] for x in ref], label=str(p))

plt.legend()
plt.show()

# ils sont ordonnes par nom de passager, donc on peut considerer que le dataset est shuffled
train, test = csv_no_na[100:], csv_no_na[:100]

tree = DecisionTreeClassifier()
tree = tree.fit(train[["age", "fare", "sex", "pclass"]], train["survived"])
print("le score du decision tree sur un test set de 100 lignes est :")
print(tree.score(test[["age", "fare", "sex", "pclass"]], test["survived"]))

# l'arbre via plt
plot_tree(tree)
plt.show()
