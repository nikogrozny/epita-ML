import matplotlib.pyplot as plt
import pandas as pd
from sklearn.svm import SVC

titanic = pd.read_csv("titanic.csv")
titanic = titanic[["age", "fare", "sex", "pclass", "survived"]].dropna()
titanic["sex"] = titanic["sex"].apply(lambda x: 0 if x == "male" else 1)

clf1 = SVC(C=1, kernel="linear")
clf10 = SVC(C=10, kernel="linear")
clf100 = SVC(C=100, kernel="linear")
clf1.fit(titanic[["age", "fare"]], titanic.survived)
clf10.fit(titanic[["age", "fare"]], titanic.survived)
clf100.fit(titanic[["age", "fare"]], titanic.survived)

colors = ["red" if s == 0 else "blue" for s in titanic.survived]
plt.scatter(titanic.age, titanic.fare, color=colors)
# TODO: plt.plot(the svm separation line)
plt.show()
