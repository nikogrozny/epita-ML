import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

titanic = pd.read_csv("titanic.csv")
titanic = titanic[["age", "fare", "sex", "pclass", "survived"]].dropna()
titanic["sex"] = titanic["sex"].apply(lambda x: 0 if x == "male" else 1)

# TODO: Tableau croisé d'effectif
# TODO: hypo thèse d'indépendance
