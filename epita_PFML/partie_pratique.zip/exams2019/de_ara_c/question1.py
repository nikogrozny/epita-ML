import matplotlib.pyplot as plt
import pandas as pd

titanic = pd.read_csv("titanic.csv")
titanic = titanic[["age", "fare", "sex", "pclass", "survived"]].dropna()
titanic["sex"] = titanic["sex"].apply(lambda x: 0 if x == "male" else 1)

colors = ["red" if s == 0 else "blue" for s in titanic.survived]
plt.scatter(titanic.age, titanic.fare, color=colors)
plt.show()
