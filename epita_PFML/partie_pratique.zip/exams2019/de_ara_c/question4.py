import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.tree import DecisionTreeClassifier

titanic = pd.read_csv("titanic.csv")
titanic = titanic[["age", "fare", "sex", "pclass", "survived"]].dropna()
titanic["sex"] = titanic["sex"].apply(lambda x: 0 if x == "male" else 1)

tree = DecisionTreeClassifier()
tree.fit(titanic[["age", "fare", "sex", "pclass"]], titanic.survived)
# About 98%, but we are scoring on the training data so it isn't really
# meaningful
print(tree.score(titanic[["age", "fare", "sex", "pclass"]], titanic.survived))

