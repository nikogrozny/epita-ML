import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from pandas.plotting import scatter_matrix
from sklearn.svm import SVC

fig = plt.figure()

sex_to_n = {'male': 0, 'female': 1}

def colors(d):
    return {1: 'green', 0: 'yellow'}[d]

df = pd.read_csv('titanic.csv')

df = df[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()
df.sex = df.sex.apply(lambda x: sex_to_n[x])

fig.add_subplot(2, 2, 1)
plt.scatter(df.age, df.fare, c=df.survived.apply(colors))
plt.ylabel("fare")
plt.xlabel("age")
fig.add_subplot(2, 2, 2)
plt.scatter(df.fare, df.age, c=df.survived.apply(colors))
plt.ylabel("age")
plt.xlabel("fare")
plt.show()
