import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from pandas.plotting import scatter_matrix
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeRegressor

sex_to_n = {'male': 0, 'female': 1}

def colors(d):
    return {1: 'green', 0: 'yellow'}[d]

df = pd.read_csv('titanic.csv')

df = df[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()
df.sex = df.sex.apply(lambda x: sex_to_n[x])

"""
QUESTION 4
"""

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(df[['age', 'fare', 'pclass', 'sex']], df.survived)


for i in [1, 2, 5, 10] :
	regr_1 = DecisionTreeRegressor(max_depth=i)
	regr_1.fit(X_train, y_train)
	print("Decision tree depth:", i, "-> score:", 1 - regr_1.score(X_test, y_test))
