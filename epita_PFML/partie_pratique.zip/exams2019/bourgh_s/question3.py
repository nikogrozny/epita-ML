import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from pandas.plotting import scatter_matrix
from sklearn.svm import SVC

fig = plt.figure()

sex_to_n = {'male': 0, 'female': 1}

def colors(d):
    return {1: 'green', 0: 'yellow'}[d]

df = pd.read_csv('titanic.csv')

df = df[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()
df.sex = df.sex.apply(lambda x: sex_to_n[x])

"""
QUESTION 3
"""

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(df[['age', 'fare']], df.survived)


for i in range(3) :
    print(10**i)
    s = SVC(kernel='linear', C=10**i)
    s.fit(X_train, y_train)
    Y_pred = pd.Series(s.predict(X_test))

    fig.add_subplot(2, 3, i+1)
    plt.scatter(X_test.age, X_test.fare, c=Y_pred.apply(colors), alpha=0.2)
    plt.ylabel("fare")
    plt.xlabel("age")

plt.show()
