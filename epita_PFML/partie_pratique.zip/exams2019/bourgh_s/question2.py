import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from pandas.plotting import scatter_matrix
from sklearn.svm import SVC

#fig = plt.figure()

sex_to_n = {'male': 0, 'female': 1}

def colors(d):
    return {1: 'green', 0: 'yellow'}[d]

df = pd.read_csv('titanic.csv')

df = df[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()
df.sex = df.sex.apply(lambda x: sex_to_n[x])

scatter_matrix(df[['sex', 'pclass']], alpha=0.6, c=df.survived.apply(colors), diagonal='hist')
plt.show()

