import matplotlib.pyplot as plt
from matplotlib import patches
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeRegressor

path = "titanic.csv"

df = pd.read_csv(path)

#Q1
df = df[['age', 'fare', 'sex', 'pclass', 'survived']]

df['sex'] = df['sex'].replace('male', 1).replace('female', 0)
print('Head :')
print(df.head())

def set_colors(d):
    if d == 0:
        return 'yellow'
    else:
        return 'green'

fig = plt.figure()
ax1 = fig.add_subplot(221)
ax1.scatter(df['age'], df['fare'], c=df['survived'].apply(set_colors))
colornames = [patches.Patch(color= 'green', label='survived'), patches.Patch(color='yellow', label='dead') ]
ax1.legend(handles=colornames)
ax1.set_title('Question 1')
#plt.show()

#Q2
crosstab = pd.crosstab(df['pclass'], df['survived'])
print("Tableau croisé d'effectifs :")
print(crosstab)
total = crosstab.sum().sum()

independant = True

for survive_ix in range(crosstab.shape[1]):
    sumY = crosstab[survive_ix].sum()
    probY = sumY / total

    for pclass_ix in range(1, crosstab.shape[0] + 1):
        probXY = crosstab[survive_ix][pclass_ix] / total
        res = probY
        res *= crosstab[survive_ix][pclass_ix] / sumY

        # Around to handle float imprecisions
        independant &= np.around(probXY,5) == np.around(res,5)

print('Independence : ' + str(independant))


# Question 3

df = df.dropna()

# Split data
X_train, X_test, y_train, y_test = train_test_split(df[['age', 'fare']], df['survived'], random_state=0)

# penalisation 1
svc = LinearSVC(C=1)

# Train
svc.fit(X_train, y_train)

svc_score = svc.score(X_test, y_test)

print('SVC 1 score : ' + str(svc_score))

predict = svc.predict(X_test)

colors = [set_colors(pred) for pred in predict]

ax2 = fig.add_subplot(222)
ax2.scatter(X_test['age'], X_test['fare'], c=colors)
colornames = [patches.Patch(color= 'green', label='survived'), patches.Patch(color='yellow', label='dead') ]
ax2.legend(handles=colornames)
ax2.set_title('Question 3 : penalisation = 1')
#plt.show()


# penalisation 10
svc = LinearSVC(C=10)

# Train
svc.fit(X_train, y_train)

svc_score = svc.score(X_test, y_test)

print('SVC 10 score : ' + str(svc_score))

predict = svc.predict(X_test)

colors = [set_colors(pred) for pred in predict]

ax2 = fig.add_subplot(223)
ax2.scatter(X_test['age'], X_test['fare'], c=colors)
colornames = [patches.Patch(color= 'green', label='survived'), patches.Patch(color='yellow', label='dead') ]
ax2.legend(handles=colornames)
ax2.set_title('Question 3 : penalisation = 10')
#plt.show()


# penalisation 100
svc = LinearSVC(C=100)

# Train
svc.fit(X_train, y_train)

svc_score = svc.score(X_test, y_test)

print('SVC 100 score : ' + str(svc_score))

predict = svc.predict(X_test)

colors = [set_colors(pred) for pred in predict]

ax2 = fig.add_subplot(224)
ax2.scatter(X_test['age'], X_test['fare'], c=colors)
colornames = [patches.Patch(color= 'green', label='survived'), patches.Patch(color='yellow', label='dead') ]
ax2.legend(handles=colornames)
ax2.set_title('Question 3 : penalisation = 100')
#plt.show()

# Question 4

# Split data
X_train, X_test, y_train, y_test = train_test_split(df[['age', 'fare', 'sex', 'pclass']], df['survived'], random_state=0)

tree = DecisionTreeRegressor(max_depth=4)

# Train
tree.fit(X_train, y_train)

tree_score = tree.score(X_test, y_test)

print('Tree score : ' + str(tree_score))

plt.show()
