import pandas as pd
import matplotlib.pyplot as plt
from sklearn.svm import *
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
import numpy as np

def question1(titanic):
    keep = ["age", "fare", "sex", "pclass", "survived"]
    titanic = titanic[keep]
    titanic.sex = titanic.sex.apply(lambda x: 0 if x == "male" else 1)
    colors = ["green" if e == 1 else "red" for e in titanic.survived]
    plt.scatter(titanic.age, titanic.fare, c=colors, alpha=0.5)
    plt.title("Question #1")
    plt.xlabel("Age")
    plt.ylabel("Fare")
    plt.show()
    return titanic

def question2(titanic):
    print("cross tab about sex and pclass")
    print(pd.crosstab(titanic.sex, titanic.pclass))
    print("Convariance of both variables: ", end="")
    print(np.cov(titanic.sex, titanic.pclass)[0,1])


def question3(titanic):
    titanic = titanic.dropna()
    xtrain, xtest, ytrain, ytest = train_test_split(titanic[["age", "fare"]], titanic.survived)
    # Linear svm are slow and have a low performance
    # Those are quicker and better, however linear can still be done by adding Linear before SVC
    # linearSvc = LinearSVC(C=..., gamma=...)
    svc1 = SVC(C=1, gamma="scale")
    svc10 = SVC(C=10, gamma="scale")
    svc100 = SVC(C=100, gamma="scale")
    svcs = [svc1, svc10, svc100]
    colors = ["green" if e == 1 else "red" for e in titanic.survived]
    for i in range(len(svcs)):
        plt.subplot(1, len(svcs), i+1)
        plt.title("SVC #" + str(i+1))
        plt.xlabel("Age")
        plt.ylabel("Fare")
        svcs[i].fit(xtrain, ytrain)
        plt.plot(svcs[i].support_[:80])
        plt.scatter(titanic.age, titanic.fare, c=colors, alpha=0.5, s=10)
        print("SVC #" + str(i+1) + ": " + str(100 * svcs[i].score(xtest, ytest)) + "%")
    plt.show()

def question4(titanic):
    titanic = titanic.dropna()
    features = ["pclass", "age", "sex", "fare"]
    xtrain, xtest, ytrain, ytest = train_test_split(titanic[features], titanic.survived)
    dtc = DecisionTreeClassifier(criterion="entropy", max_depth=3, max_features="auto")
    dtc.fit(xtrain, ytrain)
    print("DecisionTreeClassifier testing set...")
    print("Score is " + str(dtc.score(xtest, ytest) * 100) + "%")
