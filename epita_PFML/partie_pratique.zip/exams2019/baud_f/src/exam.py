from questions import *


print("READING TITANIC DATASET..")
titanic = pd.read_csv("titanic.csv")

print()
print("QUESTION #1")
titanic = question1(titanic)

print()
print("QUESTION #2")
question2(titanic)

print()
print("QUESTION #3")
question3(titanic)
print()
print("QUESTION #4")
question4(titanic)
