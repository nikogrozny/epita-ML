#EXAM

All the work is in _src/_
All the questions are in _questions.py_
They are called in _exam.py_ and it prints ouput about the exam and also shows the plots
