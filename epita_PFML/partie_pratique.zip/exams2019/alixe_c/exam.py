import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from sklearn import svm
from random import shuffle
from sklearn.tree import DecisionTreeClassifier

### Question 1
#import data, specific headers
path = "titanic.csv"
deli = ','
headers= ['age', 'fare', 'sex', 'pclass', 'survived']
df = pd.read_csv(path, delimiter=deli)[headers].dropna()
df['sex'] = df['sex'].apply(lambda x: 0 if x == "female" else 1)
#visualize
plt.subplot(1,1,1)
plt.scatter(df['age'], df['fare'], c=df.survived.apply(lambda x: 'green' if x == 1 else 'red'))


### Question 2
#tableau croise effectif
sexvspclass = pd.crosstab(df['sex'], df['pclass'])
print(sexvspclass)
#test independance
indtest = stats.chi2_contingency(np.array(sexvspclass))
print(indtest)

### Question 3
#data
obs = df[['age', 'fare']]
targ = df['survived']
#separate train and test
i_train = list(range(len(obs)))
shuffle(i_train)
x_train = obs.loc[obs.index.isin(i_train[:400])]
x_test = obs.loc[obs.index.isin(i_train[400:])]
y_train = targ.loc[targ.index.isin(i_train[:400])]
y_test = targ.loc[targ.index.isin(i_train[400:])]

#train and predict with pen 1 10 100
i = 1
for x in (1, 10, 100):
    svmLin = svm.SVC(kernel='linear', C = x)
    svmLin.fit(x_train, y_train)
    pred = pd.Series(svmLin.predict(x_test))
    plt.subplot(1, 3, i)
    plt.scatter(x_test.age, x_test.fare, c = pred.apply(lambda x: 'red' if x == 0 else 'green'))
    i += 1
plt.show()

### Question 4
#data
obs = df[['age', 'fare', 'sex', 'pclass']]
targ = df['survived']
#train/test set
i_train = list(range(len(obs)))
shuffle(i_train)
x_train = obs.loc[obs.index.isin(i_train[:400])]
x_test = obs.loc[obs.index.isin(i_train[400:])]
y_train = targ.loc[targ.index.isin(i_train[:400])]
y_test = targ.loc[targ.index.isin(i_train[400:])]

#train/predict/score
clf = DecisionTreeClassifier()
clf.fit(x_train, y_train)
score = clf.score(x_test, y_test)
print(score)

