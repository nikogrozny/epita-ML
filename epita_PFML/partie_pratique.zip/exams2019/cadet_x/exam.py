import sklearn.datasets as skdata
import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats
import sklearn.svm as sksvm
import sklearn.tree as sktree
import  sklearn.model_selection as skms
import numpy as np


def load_dataset(path):
    """Load Titanic Dataframe from path"""
    columns = ["age", "fare", "sex", "pclass", "survived"]
    dataframe = pd.read_csv(path)[columns].dropna()
    dataframe["sex"] = dataframe["sex"].astype("category").cat.codes
    return dataframe

def question1(dataframe):
    """Plots age and fare"""
    __, axs = plt.subplots(1, 1)
    survived = dataframe[dataframe["survived"] == 1]
    died = dataframe[dataframe["survived"] == 0]

    axs.scatter(survived["age"], survived["fare"], c="g", label="Survived")
    axs.scatter(died["age"], died["fare"], c="r", label="Died")

    axs.set_xlabel("age")
    axs.set_ylabel("fare")
    axs.legend()
    plt.show()

def question2(dataframe):
    """Print the the cross table of fields sex and pclass, and
    and operate an independance test via chi2_contigency"""
    cont = pd.crosstab(dataframe["sex"], dataframe["pclass"])
    print(cont)
    print("p-value: {:.3f}".format(scipy.stats.chi2_contingency(cont)[1]))

def question3(dataframe):
    """Fits a Linear SVM with different penalisation values C in (1, 10, 100)
       and displays separation line"""
    data = dataframe[["age", "fare"]].values
    target = dataframe["survived"]

    c_values = [1, 10, 100]

    __, axs = plt.subplots(2, 2)
    offset = 10
    xmin = int(data[:, 0].min() - offset)
    xmax = int(data[:, 0].max() + offset)
    ymin = int(data[:, 1].min() - offset)
    ymax = int(data[:, 1].max() + offset)
    lut_color = np.array(["r", "g"])
    for idx, c_val in enumerate(c_values, 0):
        i, j =  idx // 2, idx % 2
        svm_clf = sksvm.LinearSVC(C=c_val, random_state=123)
        svm_clf.fit(data, target)
        predictions = svm_clf.predict(data)
        surived = (predictions == 1)
        died = (predictions == 0)
        axs[i, j].scatter(data[:, 0], data[:, 1], c=predictions)
        axs[i, j].scatter(data[died, 0],
                          data[died, 1],
                          c="r", label="Died", alpha=0.6)
        axs[i, j].scatter(data[surived, 0],
                          data[surived, 1],
                          c="g", label="Survived")
        axs[i, j].set_title("LinearSVC(C={})".format(c_val))
        ref = list(np.linspace(xmin, xmax, 100))
        b,a = list(svm_clf.coef_[0]), svm_clf.intercept_[0]

        axs[i, j].legend()
        axs[i, j].plot(ref, [-b[0] * x / b[1] -a / b[1] for x in ref], label = str (10 ** (c_val - 2)))
        axs[i, j].axis([xmin, xmax, ymin, ymax])

    survived = (target == 1)
    died = (target == 0)

    axs[1, 1].scatter(data[died, 0], data[died, 1], c="r", label="Died", alpha=0.6)
    axs[1, 1].scatter(data[survived, 0], data[survived, 1], c="g", label="Survived", alpha=0.6)
    axs[1, 1].legend()
    axs[1, 1].set_title("Original".format(c_val))
    plt.show()

def question4(dataframe):
    """Train a Desion Tree classifier to prediction surival given age, fare
       sex and pclass"""
    data = dataframe.drop(["survived"], axis=1)
    target = dataframe["survived"]

    #train_data, test_data, train_target, test_target =
        #skms.train_test_split(data, target, test_size=0.2)

    dt_clf = sktree.DecisionTreeClassifier()
    dt_clf.fit(data, target)
    test_score = skms.cross_validate(dt_clf, data, target, cv=5)["test_score"]
    print("Score: {}".format(dt_clf.score(data, target)))
    print("CV Score: {}".format(test_score.mean()))

def main():
    dataframe = load_dataset("titanic.csv")
    questions = [question1, question2, question3, question4]
    for idx, question in enumerate(questions, 1):
        print("-" * 35 + " Question {}".format(idx))
        question(dataframe)
        print("-" * 80)

if __name__ == "__main__":
    main()
