import matplotlib.pyplot as plt

import pandas as pd
import numpy as np
from scipy.stats import chi2_contingency
from sklearn.svm import SVC,LinearSVC
from sklearn import tree
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split

def color(d):
    return {1:'red', 0: 'blue'}[d]
def sexual(d):
    return {"male":1, "female":0}[d]

def dataframe():
    data = pd.read_csv("titanic.csv")
    df = data[["age","fare","sex","pclass","survived"]]    
    df = df.dropna()
    df.sex = df.sex.apply(sexual)
    print(df)
    plt.scatter(df.age, df.fare, alpha=0.6 , c=df.survived.apply(color))
    plt.legend()
    plt.show()
    return df

def crosstab(df):
    print(pd.crosstab(df["sex"],df["pclass"]))
    print(chi2_contingency(df[["sex","pclass"]]))

def svm(df):
    X = df[["age","fare"]]
    Y = df.survived
    plt.scatter(X.age,X.fare,c = Y)
    ref = np.linspace(0.80,81)
    for p in [1,10,100]:
        # le 15000 iter, c'est pour eviter que les courbes partent dans les négatifs
        # et vue les datas je penses qu'il faudrait passer par un kernel trick
        clf = LinearSVC(penalty='l2',C=p, max_iter = 15000)
        FIT = clf.fit(X,Y)
        cf = FIT.coef_[0]
        ct = FIT.intercept_[0]
        plt.plot(ref,[(-cf[0] * val/cf[1])  + ct/cf[1] for val in ref])

    plt.show()
def thetree(df):
    Tree = tree.DecisionTreeClassifier()
    t,v = train_test_split(df)
    X = df[["age","sex","fare","pclass"]]
    Y = df["survived"]
    res = Tree.fit(t[["age","sex","fare","pclass"]],t.survived)
    
    y_pred = Tree.predict(v[["age","sex","fare","pclass"]])
    print(confusion_matrix(v.survived ,y_pred))

df = dataframe()
crosstab(df)
svm(df)         
thetree(df)

