import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency
from sklearn.svm import LinearSVC
from sklearn import tree

from random import shuffle

df = pd.read_csv("titanic.csv")
df = df[["age", "fare", "sex", "pclass", "survived"]]
df = df.dropna()
df["sex"] = df["sex"].map({"male": 0, "female": 1})
df["survived"] = df["survived"].map({1: "green", 0: "red"})
plt.scatter(df["age"], df["fare"], c=df["survived"])
#plt.show()
X = df[["sex", "pclass"]]
print(X, chi2_contingency(X))

X, Y = df[['age', 'fare']], df['survived']
i_train = list(range(len(X)))
shuffle(i_train)
X_train = X.loc[X.index.isin(i_train[:400])]
X_test = X.loc[X.index.isin(i_train[400:])]
Y_train = Y.loc[Y.index.isin(i_train[:400])]
ref = list(np.linspace(0, 85, 100))
for p in [1, 10, 100]:
    clf = LinearSVC(C=p).fit(X_train,Y_train)
    Y_pred = pd.Series(clf.predict(X_test))
    b, a = list(clf.coef_[0]), clf.intercept_[0]
    plt.plot(ref, [-b[0]*x/b[1] - a/b[1] for x in ref], label=str(p))

X, Y = df[['age', 'fare', 'sex', 'pclass']], df['survived']
i_train = list(range(len(X)))
shuffle(i_train)
X_train = X.loc[X.index.isin(i_train[:500])]
X_test = X.loc[X.index.isin(i_train[500:])]
Y_train = Y.loc[Y.index.isin(i_train[:500])]
Y_test = Y.loc[Y.index.isin(i_train[500:])]
clf = tree.DecisionTreeClassifier().fit(X_train, Y_train)
print("tree score:")
print(clf.score(X_test, Y_test))
plt.legend()
plt.show()

print(clf)
