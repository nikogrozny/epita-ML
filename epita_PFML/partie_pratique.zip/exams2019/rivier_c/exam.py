import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier

df = pd.read_csv('titanic.csv')

def question_1():
    df_1 = df[['age', 'fare', 'sex', 'pclass', 'survived']]
    df_1 = df_1.dropna()
    df_1.sex = df_1.sex.apply(lambda sex: 0 if sex == 'male' else 1)
    colors = df_1.survived.apply(lambda survived: 'green' if survived else 'red')
    plt.scatter(df_1.age, df_1.fare, c=colors, alpha=0.4)
    plt.show()

def question_2():
    #aFIX ME
    return

def question_3():
    df_3 = df[['age', 'fare', 'survived']]
    df_3 = df_3.dropna()
    colors = df_3.survived.apply(lambda survived: 'green' if survived else 'red')
    Y = np.array(df_3.survived)
    df_3 = df_3.drop('survived', axis=1)
    X = np.array(df_3)
    svm1 = LinearSVC()
    svm10 = LinearSVC()
    svm100 = LinearSVC()
    svm1.fit(X, Y)
    svm10.fit(X, Y)
    svm100.fit(X, Y)
    plt.scatter(X[:, 0], X[:, 1], c=colors, alpha=0.4)
    plt.show()

def question_4():
    df_4 = df[['age', 'fare', 'sex', 'pclass', 'survived']]
    df_4 = df_4.dropna()
    Y = np.array(df_4.survived)
    df_4 = df_4.drop('survived', axis=1)
    df_4.sex = df_4.sex.apply(lambda sex: 0 if sex == 'male' else 1)
    X = np.array(df_4)
    ratio = int(0.8 * len(X))
    X_train, X_test, Y_train, Y_test = X[:ratio], X[ratio:], Y[:ratio], Y[ratio:]
    dtc = DecisionTreeClassifier()
    dtc.fit(X_train, Y_train)
    print("Score is: {}.".format(dtc.score(X_test, Y_test)))

question_1()
question_2()
question_3()
question_4()
