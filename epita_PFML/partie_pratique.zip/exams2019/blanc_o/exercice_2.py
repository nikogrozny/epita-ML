# Load import

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import patches
from scipy.stats import chi2_contingency

# Load data
data = pd.read_csv('titanic.csv')

# Get only specific columns
data = data[["age", "fare", "sex", "pclass", "survived"]]

# Replace female and male by 0 and 1
data = data.replace(['female', 'male'], [0, 1])

# Create crosstab
cross = pd.crosstab(data.sex, data.pclass)
print(cross)

# Test contingency
print(chi2_contingency(cross))

