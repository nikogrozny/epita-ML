# Load import
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import patches
from sklearn.svm import SVC

# Load data
data = pd.read_csv('titanic.csv')

# Get only specific columns
data = data[["age", "fare", "sex", "pclass", "survived"]]

# Replace female and male by 0 and 1
data = data.replace(['female', 'male'], [0, 1])

# Remove row with NA as value
data = data.dropna().reset_index()

def color(x):
	return{1:'green',0: 'red'}[x]

X, Y = data[['age' , 'fare']], data.survived
s_1 = SVC(kernel = 'linear', C=1.0)
s_1.fit(X , Y)

s_10 = SVC(kernel = 'linear', C=10.0)
s_10.fit(X , Y)

s_100 = SVC(kernel = 'linear', C=100.0)
s_100.fit(X , Y)


# J'arrive bien a entrainer les 3 modèle mais quand j'essaye de la plot il semblerait qu'il y ai une erreur,
# je n'ai pas réussi à réduire la taille du plot.
plt.subplot(111)
plt.scatter(data.age , data.fare , c=Y.apply(color))
plt.plot(X, s_1.predict(X))
plt.plot(X, s_10.predict(X))
plt.plot(X, s_100.predict(X))
plt.show()
