# Load import
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import patches
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

# Load data
data = pd.read_csv('titanic.csv')
data = data[["age", "fare", "sex", "pclass", "survived"]]

data = data.replace(['female', 'male'], [0, 1])
data = data.dropna().reset_index()

X, Y = data[['age' , 'fare', 'pclass', 'sex']], data.survived

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.33)

clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)

# Il y a une précision de 75% ce qui est mieux que du random
print(clf.score(X_test, y_test))
