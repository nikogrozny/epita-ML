# Load import
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import patches


# Load data
data = pd.read_csv('titanic.csv')

# Get only specific columns
data = data[["age", "fare", "sex", "pclass", "survived"]]

# Replace female and male by 0 and 1
data = data.replace(['female', 'male'], [0, 1])

# Create lambda function to return color
def colors(d):
	return{1:'green',0: 'yellow'}[d]

# Create scatter matrix
plt.scatter(data.age,data.fare, c = data.survived.apply(colors))
plt.ylabel("tarif")
plt.xlabel('age')
colornames = [patches.Patch(color = 'green', label = 'survived'), patches.Patch(color = 'yellow' , label = 'no')]
plt.legend(handles=colornames)
plt.show()
