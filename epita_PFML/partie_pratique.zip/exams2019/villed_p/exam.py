import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import LinearSVR
from random import shuffle
from sklearn.tree import DecisionTreeClassifier



def q1():
    def sex_coding(sex):
        if sex == 'male':
            return 0
        return 1
    def color_survived(survived):
        return list(map(lambda x: 'g' if x == 1 else 'r', survived))
    df = pd.read_csv('titanic.csv')
    df = df[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()
    df.sex = [sex_coding(x) for x in df.sex]
    plt.scatter(df.age, df.fare, c=color_survived(df.survived))
    return df


def q2(df):
    fig = plt.figure(figsize=(10,20))
    ax = fig.add_subplot(5, 5, 1)
    ax.scatter(df.age, df.age)
    ax = fig.add_subplot(5, 5, 2)
    ax.scatter(df.age, df.fare)
    ax = fig.add_subplot(5, 5, 3)
    ax.scatter(df.age, df.sex)
    ax = fig.add_subplot(5, 5, 4)
    ax.scatter(df.age, df.pclass)
    ax = fig.add_subplot(5, 5, 5)
    ax.scatter(df.age, df.survived)
    
    ax = fig.add_subplot(5, 5, 6)
    ax.scatter(df.fare, df.age)
    ax = fig.add_subplot(5, 5, 7)
    ax.scatter(df.fare, df.fare)
    ax = fig.add_subplot(5, 5, 8)
    ax.scatter(df.fare, df.sex)
    ax = fig.add_subplot(5, 5, 9)
    ax.scatter(df.fare, df.pclass)
    ax = fig.add_subplot(5, 5, 10)
    ax.scatter(df.fare, df.survived)
    
    ax = fig.add_subplot(5, 5, 11)
    ax.scatter(df.sex, df.age)
    ax = fig.add_subplot(5, 5, 12)
    ax.scatter(df.sex, df.fare)
    ax = fig.add_subplot(5, 5, 13)
    ax.scatter(df.sex, df.sex)
    ax = fig.add_subplot(5, 5, 14)
    ax.scatter(df.sex, df.pclass)
    ax = fig.add_subplot(5, 5, 15)
    ax.scatter(df.sex, df.survived)

    ax = fig.add_subplot(5, 5, 16)
    ax.scatter(df.pclass, df.age)
    ax = fig.add_subplot(5, 5, 17)
    ax.scatter(df.pclass, df.fare)
    ax = fig.add_subplot(5, 5, 18)
    ax.scatter(df.age, df.sex)
    ax = fig.add_subplot(5, 5, 19)
    ax.scatter(df.pclass, df.pclass)
    ax = fig.add_subplot(5, 5, 20)
    ax.scatter(df.pclass, df.survived)
    
    ax = fig.add_subplot(5, 5, 21)
    ax.scatter(df.survived, df.age)
    ax = fig.add_subplot(5, 5, 22)
    ax.scatter(df.survived, df.fare)
    ax = fig.add_subplot(5, 5, 23)
    ax.scatter(df.survived, df.sex)
    ax = fig.add_subplot(5, 5, 24)
    ax.scatter(df.survived, df.pclass)
    ax = fig.add_subplot(5, 5, 25)
    ax.scatter(df.survived, df.survived)
    print('')
    print('Tableau de correlation:')
    print(df.corr())


def q3(df):
    X, Y = df[['fare', 'age']], df.survived
    i_train = list(range(len(X)))
    shuffle(i_train)
    X_train = X.loc[X.index.isin(i_train[:400])]
    X_test = X.loc[X.index.isin(i_train[400:])]
    Y_train = Y.loc[X.index.isin(i_train[:400])]
    Y_test = Y.loc[X.index.isin(i_train[400:])]
    logr = LinearSVR(C=1.0, max_iter=10000)
    logr.fit(X_train, Y_train)

    fig2 = plt.figure()

    def color_survived(survived):
        return list(map(lambda x: 'g' if x == 1 else 'r', survived))
    plt.scatter(df.age, df.fare, c=color_survived(df.survived))
    
    plt.plot(df.age, [x * logr.coef_[0] + logr.intercept_[0] for x in range(len(df.age)) ], c='black')
    logr = LinearSVR(C=10.0, max_iter=10000)
    logr.fit(X_train, Y_train)
    plt.plot(df.age, [logr.coef_[0] * x for x in df.age], c='black')
    logr = LinearSVR(C=100.0, max_iter=10000)
    logr.fit(X_train, Y_train)
    plt.plot(df.age, [logr.coef_[0] * x for x in df.age], c='black')



def q4(df):
    X, Y = df[['fare', 'age', 'sex', 'pclass']], df.survived
    i_train = list(range(len(X)))
    shuffle(i_train)
    X_train = X.loc[X.index.isin(i_train[:len(df) - 250])]
    X_test = X.loc[X.index.isin(i_train[len(df) - 250:])]
    Y_train = Y.loc[X.index.isin(i_train[:len(df) - 250])]
    Y_test = Y.loc[X.index.isin(i_train[len(df) - 250:])]
    clf = DecisionTreeClassifier()
    clf.fit(X_train, Y_train)
    score = clf.score(X_test, Y_test)
    print('')
    print('Score de l arbre:')
    print(score)


data = q1()
q2(data)
q3(data)
q4(data)
plt.show()
