# QUESTION 1
print("Question 1")

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


def color(elt):
	if elt == 1:
		return "r"
	else:
		return "b"


df = pd.read_csv("titanic.csv", sep=",")

df_reduced = df.loc[:, ["age", "fare", "sex", "pclass", "survived"]]

df_reduced.dropna(axis=0, inplace=True)

df_reduced["sex"] = df_reduced["sex"].apply(lambda x: 0 if x == "male" else 1)

plt.subplot(111)
plt.scatter(df_reduced["age"], df_reduced["fare"], c=df_reduced.survived.apply(lambda x: color(x)), alpha=0.4)
plt.show()


# QUESTION 2
print("Question 2")

from scipy.stats import chi2_contingency

cont = [[df_reduced.loc[(df_reduced.sex==i) & (df_reduced.pclass==j)].shape[0] for j in range(1, 4)] for i in range(0, 2)]
print(cont)
print("The independence between the variables is: {}".format(chi2_contingency(cont)))


# QUESTION 3
print("Question3")

from sklearn import svm
from sklearn.model_selection import cross_val_score

x_train = df_reduced.loc[:700, ["age", "fare"]]
y_train = df_reduced.loc[:700, ["survived"]]
x_test = df_reduced.loc[700:, ["age", "fare"]]

svm = svm.SVC(kernel="linear")
svm.C = 1

svm.fit(x_train, y_train)
y_pred = pd.Series(svm.predict(x_test))
plt.scatter(x_test.age, x_test.fare, c=y_pred.apply(color), alpha=0.4)
plt.plot([0, 10, 20, 30, 40, 50, 60], [17, 29.5, 42, 54.5, 67, 79.5, 92])
plt.show()


# QUESTION 4
print("Question 4")

from sklearn.tree import DecisionTreeClassifier

tree = DecisionTreeClassifier()

x_train = df_reduced.loc[:700, ["age", "fare", "sex", "pclass"]]
y_train = df_reduced.loc[:700, ["survived"]]
x_test = df_reduced.loc[700:, ["age", "fare", "sex", "pclass"]]
y_test = df_reduced.loc[700: , ["survived"]]

tree.fit(x_train, y_train)

tree_score = tree.score(x_test, y_test)

print("The score of the classifier is: {}".format(tree_score))
