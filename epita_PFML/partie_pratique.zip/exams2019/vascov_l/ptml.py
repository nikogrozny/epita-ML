import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as scs
from pandas.plotting import scatter_matrix
from sklearn.svm import LinearSVC
import numpy as np
from sklearn.tree import DecisionTreeClassifier

df = pd.read_csv("titanic.csv", sep=",")
df = df[["age", "fare", "sex", "pclass", "survived"]].dropna().reset_index()

def color(x):
    return ({0: "red", 1:"green"}[x])

plt.subplot(121)
plt.scatter(df["age"], df["survived"], c=df["survived"].apply(color))

plt.subplot(122)
plt.scatter(df["fare"], df["survived"], c=df["survived"].apply(color))
plt.show()

print(pd.crosstab(df["sex"], df["pclass"]))

sexes = list(df["sex"].unique())
df["sex"] = df["sex"].apply(lambda x: sexes.index(x))

# Ne marche pas?
#print(scs.chi2_contingency(df["sex"], df["pclass"]))

X = np.array(df[["age", "fare"]])
Y = np.array(df[["survived"]])

X_train = X[:-100]
Y_train = Y[:-100]

X_test = X[-100:]
Y_test = Y[-100:]

# La penalty ne marche pas?
#svc = LinearSVC(penalty='l1', loss="squared_hinge", dual=False)
svc = LinearSVC()
svc.fit(X_train, Y_train)

plt.subplot(121)
plt.scatter(df["age"], df["survived"], c=df["survived"].apply(color))
# J'ai essayé d'afficher la droite du coef mais pas assez de temps
"""test = np.linspace(0, 80, 1000)
print(test)
print(svc.coef_)
for t in test:
    plt.plot(t, t * svc.coef_[0][0])"""

plt.subplot(122)
plt.scatter(df["fare"], df["survived"], c=df["survived"].apply(color))
plt.show()

X = np.array(df[["age", "fare", "sex", "pclass"]])
X_train = X[:-100]

X_test = X[-100:]

clf = DecisionTreeClassifier()
clf.fit(X_train, Y_train)
print("Score du Decision Tree: {}".format(clf.score(X_test, Y_test)))
