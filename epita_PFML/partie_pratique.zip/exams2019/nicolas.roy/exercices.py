import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

from scipy.stats import chi2_contingency

from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB

def exercice():
    titanic = pd.read_csv('titanic.csv', sep=',')

    db = titanic[['age', 'fare', 'sex', 'pclass', 'survived']].dropna(axis=0)
    
    convert = lambda x: {'male': 0, 'female': 1}[x]
    db.sex = db.sex.apply(convert)
    
    print(db)

    get_colors = lambda x: 'green' if x else 'red'
    colors = list(map(get_colors, db.survived))
    plt.scatter(db.age, db.fare, c=colors)
    
    # Q2

    cchi2 = [[db.loc[(db.sex == s) & (db.pclass == c)].shape[0] for s in [0, 1]] for c in [1, 2, 3]]
    print(cchi2, chi2_contingency(cchi2))
 

    # Q3

    # Uncomment
    clf1 = SVC(kernel='linear', C=1.0).fit(db[['age', 'fare']], db.survived)
    #clf10 = SVC(kernel='linear', C=10.0).fit(db[['age', 'fare']], db.survived)
    #clf100 = SVC(kernel='linear', C=100.0).fit(db[['age', 'fare']], db.survived)

    # Q4

    db_train = db[['age', 'fare', 'sex', 'pclass']][:800]
    clfNB = MultinomialNB().fit(db_train, db.survived[:800])

    db_test = db[['age', 'fare', 'sex', 'pclass']][800:]
    print(clfNB.score(db_test, db.survived[800:]))
    
   # plt.show()

