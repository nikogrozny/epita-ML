import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


# Q3

df = pd.read_csv("titanic.csv", ",")

df = df[["age", "fare", "sex", "pclass", "survived"]]
df = df.dropna()


# 1 = Female !
# 0 = Male !
def sex_fix(d):
  return { 'female': 1, 'male': 0 }[d]

df["sex"] = df["sex"].apply(sex_fix)

# SVM Linear

from sklearn.svm import SVC



plt.scatter(df["age"].values, df["fare"].values, c=df['survived'].values)

ref = list(np.linspace(0, 100, 100))

for penal in [1, 10, 100]:
  print("Penalisation ", penal)
  model = SVC(kernel='linear', C=penal)
  model.fit(df[["age", "fare"]].values, df["survived"].values)
  B, A = list(model.coef_[0]), model.intercept_[0]
  plt.plot(ref, [-B[0] * x / B[1] - A/B[1] for x in ref])

plt.show()

