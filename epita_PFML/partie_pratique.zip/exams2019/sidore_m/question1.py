import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Q1

df = pd.read_csv("titanic.csv", ",")

df = df[["age", "fare", "sex", "pclass", "survived"]]

df = df.dropna()

# Debug
df.head()

def rgba_colors(d) :
  return { 1 : '9b59b6', 0 : '009900'}[d]


def colors(d) :
  return { 1 : 'green', 0 : 'red'}[d]


plt.scatter(df["age"].values, df["fare"].values, c=df["survived"].apply(colors))
plt.show()

