import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


# Q4

df = pd.read_csv("titanic.csv", ",")

df = df[["age", "fare", "sex", "pclass", "survived"]]
df = df.dropna()


# 1 = Female !
# 0 = Male !
def sex_fix(d):
  return { 'female': 1, 'male': 0 }[d]

df["sex"] = df["sex"].apply(sex_fix)



# Decision Tree

from sklearn import tree

X = df[["age", "fare", "sex", "pclass"]].values
Y = df["survived"].values.reshape(-1, 1)


clf = tree.DecisionTreeClassifier()
clf = clf.fit(X, Y)
Y_pred = clf.predict(X)
sc = clf.score(X, Y)
print("Score ", sc)
print("The score is very high ~97 %")

print("\nSplit train and test")
clf = clf.fit(X[:750], Y[:750])
sc = clf.score(X[750:], Y[750:])
print("Score on splitted ", sc)


