import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from scipy.stats import chi2_contingency

# Q2

df = pd.read_csv("titanic.csv", ",")

df = df[["age", "fare", "sex", "pclass", "survived"]]
df = df.dropna()


# 1 = Female !
# 0 = Male !
def sex_fix(d):
  return { 'female': 1, 'male': 0 }[d]

df["sex"] = df["sex"].apply(sex_fix)

# Debug
# print(df.head())



tab = pd.crosstab(df["sex"], df["pclass"])

print(tab)

cont = [[df.loc[(df.sex==j) & (df.pclass == i)].shape[0]
  for i in range(1, 4)] for j in [0, 1]]
print(cont)
print(chi2_contingency(cont))
