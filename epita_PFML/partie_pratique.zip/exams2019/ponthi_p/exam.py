import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency
from sklearn.svm import LinearSVC
import numpy as np
from sklearn.tree import DecisionTreeClassifier

def binary_sex(x):
	if x == "male":
		return 1
	return 0

def survived(x):
	return "r" if x else "b"

def question1(df):
	df = df[["age", "fare", "sex", "pclass", "survived"]]
	print(df.head(5))
	df["sex"] = df["sex"].apply(binary_sex)
	print(df.head(5))
	plt.scatter(df["age"], df["fare"], c=df.survived.apply(survived))
	plt.show()	

def question2(df):
	#Using chi2 as we have seen during class
	print(pd.crosstab(df["pclass"], df["survived"]))	
	cont = [[df.loc[(df.survived == j) & (df.pclass == i)].shape[0] for i in range(1,4)] for j in [0, 1]] 
	print(chi2_contingency(cont))

def question3(df):
	t = df[["age", "fare", "survived"]].dropna()
	X, Y = t[["age", "fare"]], t["survived"]
	print(X.dropna())
	print(Y)
	ref = list(np.linspace(0, 100, 100))
	for p in ([1, 10, 100]):
		clf = LinearSVC(C=p)
		clf.fit(X, Y)
		b, a = list(clf.coef_[0]), clf.intercept_[0]
		plt.plot(ref, [-b[0]*x/b[1]-a/b[1] for x in ref], label=str(p))
	plt.scatter(df["age"], df["fare"])
	plt.legend()
	plt.show()	
	

def question4(df):
	clf = DecisionTreeClassifier(random_state=0)
	df["sex"] = df["sex"].apply(binary_sex)
	t = df[["age", "fare", "sex", "pclass", "survived"]].dropna()
	print(t.shape)	
	#Let's split the data set (~80/20 for training/test)
	train_x, train_y = t[["age", "fare", "sex", "pclass"]][:800], t["survived"][:800]
	clf.fit(train_x, train_y)
	test_x, test_y = t[["age", "fare", "sex", "pclass"]][800:], t["survived"][800:]
	print(clf.score(test_x, test_y))
	
df = pd.read_csv("titanic.csv")
question1(df)
question2(df)
question3(df)
question4(df)
