import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

df = pd.read_csv('titanic.csv')

sex_to_binary = {'male': 1, 'female': 0}
df = df[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()
df.sex = df.sex.apply(lambda x : sex_to_binary[x])

def survived(s):
    return {0: 'red', 1: 'green'}[s]
fig, ax = plt.subplots()
ax.set(xlabel='Age', ylabel='Fare')

ax.scatter(df.age, df.fare, c=df.survived.apply(survived))

cont = [[df.loc[(df.sex == i) & (df.pclass == j)].shape[0] for j in range(1,4)] for i in [0,1]]
print('chi2 :', chi2_contingency(cont))
print('These variables are not completely independant')
print()

penalties = [1.0, 10.0, 100.0]
xs = list(np.linspace(1, 80, 200))
for p in penalties:
    svm = SVC(kernel='linear', C=p, max_iter=10000)
    svm.fit(df[['age', 'fare']], df.survived)
    coef = list(svm.coef_[0])
    const = svm.intercept_[0]
    ax.plot(xs, [coef[0] * x / coef[1] + const / coef[1] for x in xs], label=str(p))
    ax.set_ylim([0, 300])
plt.legend(loc='best')
print()
dtree = DecisionTreeClassifier()
dtree.fit(df[['age', 'fare', 'sex', 'pclass']], df.survived)
print('Tree score: ', dtree.score(df[['age', 'fare', 'sex', 'pclass']], df.survived))
print('NB: This score is computed over the same data the tree was trained on, so it is not very useful')
plt.show()
