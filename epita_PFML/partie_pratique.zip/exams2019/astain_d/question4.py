import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

df = pd.read_csv("titanic.csv")[["age", "fare", "sex", "pclass", "survived"]].dropna()

#Question 4:

def normalize(x):
    if x == "female":
        return 0
    return 1

df.sex = df.sex.apply(normalize)

X_train, X_test, y_train, y_test = train_test_split(df[["age", "fare", "sex", "pclass"]], df.survived, random_state=3)

tree = DecisionTreeClassifier(max_leaf_nodes=3, random_state=3)

tree.fit(X_train, y_train)

y_pred = tree.predict(X_test)

error = accuracy_score(y_test, y_pred)
print(error)

