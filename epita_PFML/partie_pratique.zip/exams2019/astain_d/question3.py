from sklearn import svm
from sklearn.model_selection import train_test_split
import pandas as pd
from matplotlib import pyplot as plt
import numpy as np



df = pd.read_csv("titanic.csv")[["age", "fare", "sex", "pclass", "survived"]].dropna()

#Question 3:

X = df[["age", "fare"]]
y = df.survived

X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=3)

ref = list(np.linspace(0, 80, 800))

plt.scatter(X_train.values[:, 0], X_train.values[:, 1], c=y_train.values)

for p in range(3):
    vm = svm.LinearSVC(C=10**p)
    vm.fit(X_train, y_train)
    b, a = list(vm.coef_[0]), vm.intercept_[0]
    plt.plot(ref, [-b[0]*x/b[1]-a/b[1] for x in ref], label = str(10**p))

plt.xlabel("age")
plt.ylabel("fare")

plt.legend()
plt.show()
