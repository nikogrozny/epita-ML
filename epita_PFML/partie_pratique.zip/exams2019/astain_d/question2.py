import pandas as pd
from matplotlib import pyplot as plt
import numpy as np


df = pd.read_csv("titanic.csv")[["age", "fare", "sex", "pclass", "survived"]]

#Question 2:
# triste de ne pas avoir sns :'(

plt.subplot(1, 2, 1)
plt.scatter(df.sex, df.pclass, c=df.survived)
plt.show()

