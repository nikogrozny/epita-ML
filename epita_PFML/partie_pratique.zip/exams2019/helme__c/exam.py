#! /usr/bin/env python

import pandas as pd
import numpy as np
from pandas import crosstab
from matplotlib import pyplot as plt
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split, cross_val_score

# Question 1
def get_data():
	df = pd.read_csv('./titanic.csv')
	df = df[["age", "fare", "sex", "pclass", "survived"]].dropna()
	sex = list(set(df.sex))
	sexToInt = dict(zip(sex, range(0, len(sex))))
	df.sex = df.sex.apply((lambda x: sexToInt[x]))

	return df

def visualize_data(df):
	plt.figure()
	plt.scatter(df.age, df.fare, c=df.survived)
	plt.show()

# Question 2
def crosstabs(df):
	# Nice documentation
	#crosstab(df, columns=["sex", "pclass"])
	print(crosstab(df.sex, df.pclass))
	# chi 2 for indep

# Question 3
def plot_line(clf, values, targets):
	min_x = np.min(values.age)
	max_x = np.max(values.age)

	# get the separating hyperplane
	w = clf.coef_[0]
	a = -w[0] / w[1]
	xx = np.linspace(min_x - 5, max_x + 5) # make sure the line is long enough
	yy = a * xx - (clf.intercept_[0]) / w[1]
	plt.plot(xx, yy, 'k--', label='Class 1')

def lin_svm(df):
	i = 1
	plt.figure()
	values = df[["age", "fare"]]
	targets = df[["survived"]].values.ravel()
	for p in list((1, 10, 100)):
		clf = SVC(kernel='linear', C=p)
		clf = clf.fit(values, targets)
		print(clf.coef_)
		plt.subplot(1, 3, i)
		plt.scatter(values.age, values.fare, c=targets)
		plot_line(clf, values, targets)
		plt.title("Penalty = %d" % p)
		i+=1
	plt.show()

# Question 4
def my_dtr(df):
	values = df[["age", "fare", "sex", "pclass"]]
	targets = df[["survived"]]
	x_train, x_test, y_train, y_test = train_test_split(values, targets)
	dtr = DecisionTreeRegressor(random_state=0)
	dtr = dtr.fit(x_train, y_train)
	score1 =  dtr.score(x_test, y_test)
	print("Tree score 1", score1)
	score2 = cross_val_score(dtr, values, targets, cv=10)
	print("Tree score 2 (cross validation)", score2)
	y_pred = dtr.predict(x_test)

if __name__ == "__main__":
	df = get_data()
	visualize_data(df)
	crosstabs(df)
	lin_svm(df)
	my_dtr(df)
