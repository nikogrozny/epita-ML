import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


#Question 1
df1 = pd.read_csv("titanic.csv")
titanic = df1[["age", "fare", "sex", "pclass", "survived"]].dropna()
titanic = titanic.replace("male", 0)
titanic = titanic.replace("female", 1)

x = titanic["age"]
y = titanic["fare"]

c = []

for i in titanic["survived"]:
    if i == 0:
        c += ["red"]
    else:
        c += ["blue"]

fig, ax = plt.subplots()
ax.scatter(x, y, color=c)
plt.show()

#Question 2

pd.plotting.scatter_matrix(titanic[["age" , "fare", "sex", "pclass"]], alpha =0.6, c=c, diagonal="hist")
plt.show()
"""
On peut voir qu'il y a une corelation entre le sex, le pclass, et la survit du passager
"""

#Question 3

from sklearn.svm import SVC

X_train = titanic[["age", "fare"]][:1000]
X_test = titanic[["age", "fare"]][300:]
Y_train = titanic[["survived"]][:1000]
Y_test = np.array(titanic[["survived"]][300:])


clf = SVC().fit(X_train, Y_train)
predict = clf.predict(X_test)



res = predict.reshape(1, -1) - Y_test.reshape(1, -1)

zeros = 0

for i in res[0]:
    if i == 0:
        zeros += 1

print("acc =")
print(zeros / res.shape[1])

#Question 4

from sklearn.tree import DecisionTreeClassifier

X_train2 = titanic[["age", "fare", "sex", "pclass"]][:1000]
X_test2 = titanic[["age", "fare", "sex", "pclass"]][300:]
Y_train2 = titanic[["survived"]][:1000]
Y_test2 = np.array(titanic[["survived"]][300:])

clf2 = DecisionTreeClassifier().fit(X_train2, Y_train2)
predict2 = clf2.predict(X_test2)

res2 = predict2.reshape(1, -1) - Y_test2.reshape(1, -1)

zeros2 = 0

for i in res2[0]:
    if i == 0:
        zeros2 += 1

print("tree acc =")
print(zeros2 / res2.shape[1])

