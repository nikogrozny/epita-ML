import matplotlib.pyplot as plt
from matplotlib import patches
import numpy as np
import pandas as pd
from sklearn.svm import SVC
import os

file = "titanic.csv"

data = pd.read_csv(file, sep=',')

def question1():
    df = data[['age', 'fare', 'sex', 'pclass', 'survived']]
    df = df.replace('male', 0).replace('female', 1)

    def colors(d):
        return {1: "green", 0: 'red'}[d]

    plt.scatter(df.age, df.fare, c=df.survived.apply(colors))

    plt.xlabel = ('age')
    plt.ylabel = ('fare')

    colornames = [patches.Patch(color="green", label="survived"),
                      patches.Patch(color='red', label="died")]
    plt.legend(handles=colornames)
    plt.show()
    return 0

def question2():
    return 1

def question3():
    X = data[['age', 'fare']]
    Y = data.survived
    proportion = 0.80 * data.shape[0]
    return 2

def question4():
    return 3


def main():
    question1()
    question3()

main()
