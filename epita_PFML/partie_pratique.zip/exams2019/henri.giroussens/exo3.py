import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


data = pd.read_csv("./titanic.csv")
data = data[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()

def colors(d):
    return {1:'green', 0:'yellow'}[d]

from sklearn.svm import SVC
from random import shuffle

data = data.reset_index()
X, Y = data[['age', 'fare']], data.survived
i_train = list(range(len(X)))
shuffle(i_train)
X_train=X.loc[X.index.isin(i_train[:400])]
X_test=X.loc[X.index.isin(i_train[400:])]
Y_train=Y.loc[Y.index.isin(i_train[:400])]
s = SVC(kernel='linear') ### sans la doc scikit, pas de pénalisation, je crois que SVC(1, kernel...) fonctionne
s.fit(X_train, Y_train)
Y_pred = pd.Series(s.predict(X_test))
plt.subplot(121)
plt.scatter(X_test.age, X_test.fare, c=Y_pred.apply(colors), alpha=0.2)
plt.scatter(X_train.age, X_train.fare, c=Y_train.apply(colors))
plt.subplot(122)
plt.scatter(X.age, X.fare, c=Y.apply(colors))
plt.show()
