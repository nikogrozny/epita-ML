import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


### exo 1

data = pd.read_csv("./titanic.csv")
data = data[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()
plt.subplot(121)
def colors(d):
    return {1:'green', 0:'yellow'}[d]

plt.scatter(data.age, data.fare, c=data.survived.apply(colors))

plt.show()
