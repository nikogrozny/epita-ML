import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from random import gauss

data = pd.read_csv("./titanic.csv")
data = data[['age', 'fare', 'sex', 'pclass', 'survived']].dropna()

from pandas.plotting import scatter_matrix
colMap={0:"red",1:"green"}
color=list(map(lambda x:colMap.get(x), data.survived))
data.sex = data.sex.apply(lambda x:{'male':0, 'female':1}[x])

plt.subplot(121)
data['sex'] = data['sex'].apply(lambda x:x+gauss(0,0.05))
scatter_matrix(data[['sex', 'pclass']], alpha=0.6, c=color, diagonal='hist')

from scipy.stats import chi2_contingency

cont = [[data.loc[(data.sex==j) & (data.pclass==i)].shape[0] for i in range(1,4)] for j in ['male', 'female']]
print(cont, chi2_contingency(cont))


plt.show()
