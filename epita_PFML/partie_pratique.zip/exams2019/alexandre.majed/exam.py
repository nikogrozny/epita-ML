import pandas as pd
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

df = pd.read_csv("titanic.csv")
df = df[["age", "fare", "sex", "pclass", "survived"]]
df = df.dropna(axis=0)
df.sex = df.sex.apply(lambda x: {'male' : 0 , 'female': 1} [x])

def question1(df):
	print("Question 1:\n")
	plt.scatter(df["age"], df["fare"], c=df["survived"])
	plt.show()
	print()

def question2(df):
	print("Question 2:\n")
	class_sex = df[["pclass", "sex"]]
	values = []
	for sex in range(2):
		classes = []
		for pclass in range(1, 4):
			classes.append(len(class_sex[(class_sex.sex==sex) & (class_sex.pclass==pclass)]))
		values.append(classes)
	print("pclass  1    2   3")
	print("male  ", values[0])
	print("female", values[1])
	print()

def question3(df):
	print("Question 3:\n")
	for i, c in enumerate([1, 10, 100]):
		print("Computing for c=", c)
		plt.subplot(1, 3, i + 1)
		survived = SVC(C=c, kernel='linear')
		survived.fit(df[["age", "fare"]], df["survived"])
		pred = survived.predict(df[["age", "fare"]])
		plt.scatter(df["age"], df["fare"], c=pred)
	plt.show()
	print()

def question4(df):
	print("Question 4:\n")

	n = int(0.8 * len(df))
	X_train = df[["age", "fare", "sex", "pclass"]][:n]
	X_test = df[["age", "fare", "sex", "pclass"]][n:]
	Y_train = df["survived"][:n]
	Y_test = df["survived"][n:]

	tree = DecisionTreeClassifier(criterion="entropy", min_samples_split=4)
	tree.fit(X_train, Y_train)

	print(tree.score(X_test, Y_test))
	print()

question1(df)
question2(df)
question3(df)
question4(df)
