import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier, plot_tree

def sex2num(sex):
	return 1 if sex == "male" else 0

def survived2color(survived):
  return 'b' if survived else 'r'

df_base = pd.read_csv("titanic.csv")
df = df_base[["age", "fare", "sex", "pclass", "survived"]]
df.sex = df.sex.apply(sex2num)

def q1(df):
	plt.scatter(df.age, df.fare, c=df.survived.apply(survived2color))
	plt.show()

def q2(df):
	sex_list = df.sex.drop_duplicates()
	pclass_list = df.pclass.drop_duplicates()
	cross_ef = np.zeros((2, 3))
	df = df.dropna()
	for sex, pclass in df[["sex", "pclass"]].values:
		cross_ef[sex, pclass - 1] += 1
	
	print("\nCross effectif table : \n\n", cross_ef)

	test = chi2_contingency(df[["sex", "pclass"]])
	print("\nIndependancy Test : \n\n", test)
	return

def q3(df):
	df = df.dropna()

	for i in range(3):
		svm = LinearSVC(C=[1, 10, 100][i])
		svm.fit(df[["age", "fare"]], df.survived)
		a,b = svm.coef_[0]
		x = np.arange(1,80,1)
		y = a*x + b
		plt.subplot(1, 3, i+1)
		plt.scatter(df.age, df.fare, c=df.survived.apply(survived2color))
		plt.plot(x, y, c='c')
	plt.show()

def q4(df):
	df = df.dropna()
	dtc = DecisionTreeClassifier()
	dtc.fit(df[["age", "fare", "sex", "pclass"]], df.survived)
	print("\nDescision Tree SCORE : \n\n", dtc.score(df[["age", "fare", "sex", "pclass"]], df.survived))
	plot_tree(dtc)
	plt.show()

q1(df)
q2(df)
q3(df)
q4(df)
